const job_title = document.querySelector('.jobTitle');
const image_src = document.querySelector('.imageSrc');
const btn_submit = document.querySelector('.submit');

btn_submit.addEventListener('click', function(){


});